TEMPLATE_DEFAULTS = {
    "customLabels": {},
    "emptyValue": "",
    "fieldBlockGroups": {},
    "outputColumns": [],
    "preProcessors": [],
    "processingImageShape": [820, 666],
    "sortFiles": {
        "enabled": False,
    },
}
