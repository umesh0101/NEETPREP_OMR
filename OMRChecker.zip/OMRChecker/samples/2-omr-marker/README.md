### OMRChecker Sample

This sample demonstrates multiple things, namely -
- Running OMRChecker on images scanned using popular document scanning apps
- Using a common template.json file for sub-folders (e.g. multiple scan batches)
- Using evaluation on custom labels
